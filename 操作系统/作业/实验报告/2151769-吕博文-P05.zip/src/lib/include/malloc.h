#ifndef MALLOC_H
#define MALLOC_H

#include <stddef.h>

void* malloc(unsigned int);
int free(void*);

#endif
