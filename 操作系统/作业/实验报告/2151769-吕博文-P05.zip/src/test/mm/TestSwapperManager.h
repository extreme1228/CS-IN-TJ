#ifndef TEST_SWAPPER_MANAGER_H
#define TEST_SWAPPER_MANAGER_H

#include "..\KernelInclude.h"

void PrintMapNode(SwapperManager& swapMgr, int index);

void PrintAllMapNode(SwapperManager& swapMgr);

bool TestSwapperManager();

#endif
