#ifndef TEST_NEW_H
#define TEST_NEW_H

bool TestNew();

#endif