#ifndef TEST_ALLOCATOR_H
#define TEST_ALLOCATOR_H

bool TestAllocator();

#endif