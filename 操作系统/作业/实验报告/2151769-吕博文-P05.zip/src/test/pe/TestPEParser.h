#ifndef TEST_PE_PARSER
#define TEST_PE_PARSER

bool TestPEParser();

#endif 